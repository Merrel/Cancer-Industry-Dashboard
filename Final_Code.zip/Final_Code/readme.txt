// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
// NECESSARY SOFTWARE

- Ran on Python 3.7.6

Python libraries {install with: $pip install [library]}:
    - [sklearn] v. 0.22.1
    - [websockets] v. 8.1
    - [asyncio] v. 3.4.3
    - [numpy] v. 1.18.1


// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
// INSTRUCTIONS

- Open console in root directory and run:
    - $cd national_choropleth
    - $python -m http.server 8000

- Open new console at root directory and run:
    - $cd national_choropleth/src
    - $python server.py

- Open web browser and goto url: 
    - localhost:8000

- Enjoy visualiztions!